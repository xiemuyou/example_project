package com.doushi.library.widgets.canrefresh;

/**
 * Created by xuleyuan on 2017/9/14
 */

public interface OnScrollListener {
    void onScroll(int scrollY);
}
