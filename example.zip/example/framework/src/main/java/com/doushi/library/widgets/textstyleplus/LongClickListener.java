package com.doushi.library.widgets.textstyleplus;

/**
 * LongClickListener <br/>
 * Created by xiaqiulei on 2016-11-30.
 */
public interface LongClickListener {

    void longClick(String text);
}