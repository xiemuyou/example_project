package com.doushi.library.widgets.dialog.upload;

/**
 * Created by xuleyuan on 2017/9/15
 */
public interface Indeterminate {
    void setAnimationSpeed(float scale);
}