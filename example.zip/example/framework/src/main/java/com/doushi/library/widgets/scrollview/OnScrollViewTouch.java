package com.doushi.library.widgets.scrollview;

/**
 * Created by xuleyuan on 2017/8/14
 */
public interface OnScrollViewTouch {
    void onTouch();
    void onRelease();
}
