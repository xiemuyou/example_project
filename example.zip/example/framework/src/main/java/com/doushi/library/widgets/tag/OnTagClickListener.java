package com.doushi.library.widgets.tag;

public interface OnTagClickListener {
    void onTagClick(int position, Object tag);
}
