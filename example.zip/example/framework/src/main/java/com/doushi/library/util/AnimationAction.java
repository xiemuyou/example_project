package com.doushi.library.util;

/**
 * Created by xuleyuan on 2017/11/2
 */

interface AnimationAction {
    void action();
    void onEnd();
}
