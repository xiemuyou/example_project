package com.doushi.library.widgets.textstyleplus;

/**
 * ClickListener <br/>
 * Created by xiaqiulei on 2016-11-30.
 */
public interface ClickListener {

    void click(String text);
}