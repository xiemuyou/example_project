package com.doushi.library.util;

/**
 * Created by xuleyuan on 2017/11/2
 */

public interface CurrentEndListener {
    void onEnd(String tag);
}
