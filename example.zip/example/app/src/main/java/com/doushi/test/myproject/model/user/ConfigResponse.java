package com.doushi.test.myproject.model.user;

import com.doushi.test.myproject.model.base.BaseApiResponse;

/**
 * LoginByToken 返回数据
 *
 * @author xiemy
 * @date 2017/8/10.
 */
public class ConfigResponse extends BaseApiResponse<ConfigData> {
}
