package com.doushi.test.myproject.model.base

/**
 * 请求网络返回数据字符串基类
 *
 * @author xiemy
 * @date 2017/4/19.
 */
class StringResponse : BaseApiResponse<String>()
