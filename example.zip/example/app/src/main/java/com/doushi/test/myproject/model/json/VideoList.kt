package com.doushi.test.myproject.model.json

import com.doushi.test.myproject.model.sort.NewsSortInfo
import com.doushi.test.myproject.model.sort.NewsSortListResponse
import com.doushi.test.myproject.model.user.UserInfo
import com.doushi.test.myproject.model.video.VideoDetails
import com.doushi.test.myproject.model.video.VideoListResponse
import org.json.JSONException
import org.json.JSONObject

import java.util.ArrayList

/**
 * @author xiemy2
 * @date 2019/6/19
 */
class VideoList {

}
