package com.doushi.test.myproject.model.sort

/**
 * @author xiemy2
 * @date 2019/5/27
 */
data class NewsSortListResponse(var version: String? = null, var data: List<NewsSortInfo>? = ArrayList())