package com.doushi.test.myproject.ui.movie;

import android.os.Bundle;

import com.doushi.test.myproject.base.component.BaseActivity;

/**
 * @author xiemy1
 * @date 2018/11/7
 */
public class MovieActivity extends BaseActivity {

    @Override
    public int getLayoutId(Bundle savedInstanceState) {
        return 0;
    }

    @Override
    public void initEnv() {

    }
}
