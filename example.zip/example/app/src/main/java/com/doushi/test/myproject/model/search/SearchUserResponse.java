package com.doushi.test.myproject.model.search;

import com.doushi.test.myproject.model.base.BaseApiResponse;

/**
 * 搜索用户
 *
 * @author xiemy
 * @date 2017/8/22.
 */
public class SearchUserResponse extends BaseApiResponse<SearchUserList> {
}
