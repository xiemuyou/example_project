package com.doushi.test.myproject.global;

/**
 * 全局常量
 *
 * @author xiemy
 * @date 2018/2/28.
 */
public class Constants {
    /**
     * 极光设备ID
     */
    public static String JG_DEVICE_ID = "";
    /**
     * 默认一页加载数量
     */
    public static final int CNT_NUMBER = 10;
}
