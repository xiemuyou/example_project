package com.doushi.test.myproject.ui.test

/**
 * @author xiemy2
 * @date 2019/5/16
 */
class KotlinTest {
//    fun main(args: Array<String>) {
//        println("hello word!")
//    }
}