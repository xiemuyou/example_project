package com.doushi.test.myproject.widgets.extra;

/**
 * @author xiemy1
 * @date 2018/6/27
 */
public interface IGetLineSpaceExtra {
    int getSpaceExtra();
}
